$ASDF_DIR/installs/haskell/9.8.2/bin/alex Lexer.x -o Lexer.hs
$ASDF_DIR/installs/haskell/9.8.2/bin/happy Parser.y -o Parser.hs